# XYF GitHub Pages 测试网站

这是一个纯 HTML/CSS/JavaScript 的测试网站。

## 部署到 GitHub Pages

1. 创建一个 GitHub 仓库。
2. 上传 `index.html`。
3. 打开仓库的 Settings → Pages。
4. 在 Build and deployment 中选择从分支部署（Deploy from a branch）。
5. 选择 `main` 分支和 `/ (root)`。
6. 保存并等待部署完成。
7. GitHub 会提供一个公开访问网址。

网站入口文件必须叫 `index.html`。
